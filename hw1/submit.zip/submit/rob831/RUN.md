
# RUN.md

This README lists the exact commands (with hyperparameters) to reproduce the numbers and figures in the report. Paths are written relative to the repository root
---

## 1) Behavior Cloning (BC) — main results (100k training steps)

These are the runs used in Part 3 for **Ant-v2** and **Humanoid-v2**.
Model: MLP (tanh) with **2×128** hidden units, learning rate **3e-4**, training batch **1024**, **100,000** gradient steps, `n_iter=1`, seed `1`.
Evaluation uses at least 5 rollouts (`eval_batch_size` chosen accordingly).

### Ant-v2 (BC, 100k steps)

```bash
python rob831/scripts/run_hw1.py \
  --expert_policy_file rob831/policies/experts/Ant.pkl \
  --expert_data       rob831/expert_data/expert_data_Ant-v2.pkl \
  --env_name Ant-v2 \
  --exp_name q1_bc_ant_fixed_2x128_lr3e-4_steps100k \
  --n_iter 1 \
  --n_layers 2 --size 128 \
  --learning_rate 3e-4 \
  --train_batch_size 1024 \
  --num_agent_train_steps_per_iter 100000 \
  --eval_batch_size 5000 \
  --video_log_freq -1 --scalar_log_freq 1 \
  --seed 1
```

### Humanoid-v2 (BC, 100k steps)

```bash
python rob831/scripts/run_hw1.py \
  --expert_policy_file rob831/policies/experts/Humanoid.pkl \
  --expert_data       rob831/expert_data/expert_data_Humanoid-v2.pkl \
  --env_name Humanoid-v2 \
  --exp_name q1_bc_humanoid_fair_2x128_lr3e-4_steps100k \
  --n_iter 1 \
  --n_layers 2 --size 128 \
  --learning_rate 3e-4 \
  --train_batch_size 1024 \
  --num_agent_train_steps_per_iter 100000 \
  --eval_batch_size 20000 \
  --video_log_freq -1 --scalar_log_freq 1 \
  --seed 1
```

> You’ll get directories like:
>
> * `data/q1_bc_ant_fixed_2x128_lr3e-4_steps100k_Ant-v2_<timestamp>`
> * `data/q1_bc_humanoid_fair_2x128_lr3e-4_steps100k_Humanoid-v2_<timestamp>`

Those are the BC paths I used in the figures.

---

## 2) Behavior Cloning — hyperparameter sweep for Part 4 (vary training steps)

We sweep the number of gradient steps while holding everything else fixed (same model and data). For Ant-v2 we used steps = **1k, 5k, 10k, 30k, 50k, 100k** and 3 seeds (1–3). Example bash loops:

### Ant-v2 sweep (steps × seeds)

```bash
for steps in 1000 5000 10000 30000 50000 100000; do
  for seed in 1 2 3; do
    python rob831/scripts/run_hw1.py \
      --expert_policy_file rob831/policies/experts/Ant.pkl \
      --expert_data       rob831/expert_data/expert_data_Ant-v2.pkl \
      --env_name Ant-v2 \
      --exp_name q1_bc_ant_steps${steps}_2x128_lr3e-4_bs1024_s${seed} \
      --n_iter 1 \
      --n_layers 2 --size 128 \
      --learning_rate 3e-4 \
      --train_batch_size 1024 \
      --num_agent_train_steps_per_iter ${steps} \
      --eval_batch_size 10000 \
      --video_log_freq -1 --scalar_log_freq 1 \
      --seed ${seed}
  done
done
```

> The plotting script for Part 4 reads these directories, groups by `${steps}`, and averages across seeds using `Eval_AverageReturn` and `Eval_StdReturn` (or recomputes std across the seeds).

If you also want to run the same sweep for Humanoid-v2 (optional), mirror the command above and swap the expert files/env name (consider `eval_batch_size 20000` for \~10 rollouts).

---

## 3) DAgger — Ant-v2 and Humanoid-v2 (8 iterations, 3 seeds)

We keep the same network and optimizer hyperparameters as BC for a fair comparison. Each DAgger iteration relabels on-policy observations with the expert, aggregates data, then continues supervised training.

**Shared hyperparameters** (both envs):

* `--do_dagger`
* `--n_iter 8`
* MLP (tanh) `--n_layers 2 --size 128`
* `--learning_rate 3e-4`
* `--train_batch_size 1024`
* `--num_agent_train_steps_per_iter 2000`  *(per DAgger iteration; adjust if you want longer training per iter)*
* Evaluation: at least 5 rollouts (`--eval_batch_size 10000` for Ant, `20000` for Humanoid)
* Seeds: 1, 2, 3 (used to compute the shaded std region in the learning curves)

### Ant-v2 (DAgger, 8 iterations, seeds 1–3)

```bash
for seed in 1 2 3; do
  python rob831/scripts/run_hw1.py \
    --expert_policy_file rob831/policies/experts/Ant.pkl \
    --expert_data       rob831/expert_data/expert_data_Ant-v2.pkl \
    --env_name Ant-v2 \
    --exp_name q2_dagger_ant_s${seed} \
    --do_dagger \
    --n_iter 8 \
    --n_layers 2 --size 128 \
    --learning_rate 3e-4 \
    --train_batch_size 1024 \
    --num_agent_train_steps_per_iter 2000 \
    --eval_batch_size 10000 \
    --video_log_freq -1 --scalar_log_freq 1 \
    --seed ${seed}
done
```

### Humanoid-v2 (DAgger, 8 iterations, seeds 1–3)

```bash
for seed in 1 2 3; do
  python rob831/scripts/run_hw1.py \
    --expert_policy_file rob831/policies/experts/Humanoid.pkl \
    --expert_data       rob831/expert_data/expert_data_Humanoid-v2.pkl \
    --env_name Humanoid-v2 \
    --exp_name q2_dagger_humanoid_s${seed} \
    --do_dagger \
    --n_iter 8 \
    --n_layers 2 --size 128 \
    --learning_rate 3e-4 \
    --train_batch_size 1024 \
    --num_agent_train_steps_per_iter 2000 \
    --eval_batch_size 20000 \
    --video_log_freq -1 --scalar_log_freq 1 \
    --seed ${seed}
done
```

> You’ll get run directories like `data/q2_dagger_ant_s1_Ant-v2_<timestamp>` and `data/q2_dagger_humanoid_s2_Humanoid-v2_<timestamp>`.
> The DAgger learning curves in the report were produced by averaging these three seeds per iteration and overlaying horizontal lines for the expert and the BC baseline.

---

## 4) Optional: quick one-liners to print expert dataset stats (Part 2 table)

```bash
# Ant-v2
python -c "import pickle, numpy as np; d=pickle.load(open('rob831/expert_data/expert_data_Ant-v2.pkl','rb')); R=[p['reward'].sum() for p in d]; print('Ant-v2 expert mean/std/n =', np.mean(R), np.std(R), len(R))"

# Humanoid-v2
python -c "import pickle, numpy as np; d=pickle.load(open('rob831/expert_data/expert_data_Humanoid-v2.pkl','rb')); R=[p['reward'].sum() for p in d]; print('Humanoid-v2 expert mean/std/n =', np.mean(R), np.std(R), len(R))"
```

---

